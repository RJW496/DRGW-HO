#if !defined __BICOLOR__
#define __BICOLOR__

// The following code defines the BICOLOR LED class
//
// This is for a TWO LEAD bicolor LED: passing current in one direction results in
// a green color; passing current in the other direction results in red color. Yellow
// can be achieved by alternating rapidly between green and red.
//
#define OFF 0
#define GRN 1
#define RED 2
#define YLW 3

class BICOLOR {
  public:
    BICOLOR(unsigned pin1, unsigned pin2);
    BICOLOR(unsigned pin1, unsigned pin2, unsigned grnDelay, unsigned redDelay);
    void on(int color);
    void blink(unsigned color, unsigned onTime, unsigned offTime);
    void refresh();
    void off();
    void setGrnDelay(unsigned delay);
    void setRedDelay(unsigned delay);
  private:
    void _red();                // sets LED state to RED
    void _grn();                // sets LED state to GRN
    void _off();                // sets LED state to OFF
    unsigned _pin1;             // LED pin assignments = NOTE this class is for a
    unsigned _pin2;             //   2 pin bicolor LED
    unsigned _grnDelay;         // time (msec) to display green to obtain yellow color
    unsigned _redDelay;         // time (msec) to display red to obtain yellow color
    unsigned long _timex;       // current cycle time (used for displaying yellow color)
    unsigned _state;            // LED state - valid values are OFF, GRN, or RED
    unsigned _color;            // LED color - valid values are OFF, GRN, RED, or YLW
    bool     _blink;             // a value of true means current _color is blinking
    unsigned _onTime;           // time (msec) while current color is ON
    unsigned _offTime;          // time (msec) while current color if OFF
    unsigned long _cycleStart;  // start time (msec) of current blink cycle
};

#endif
