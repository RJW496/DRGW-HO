#include "Arduino.h"
#include "signal_6.h"

/*
 *  This class controls a six-light signal with six distinct LEDs
 *  Note the LEDs might be two true tricolor LEDs
 */

SIGNAL_6::SIGNAL_6(unsigned grnPin1, unsigned ylwPin1, unsigned redPin1, unsigned grnPin2, unsigned ylwPin2, unsigned redPin2) {
  _grnUpper = new LED(grnPin1);
  _ylwUpper = new LED(ylwPin1);
  _redUpper = new LED(redPin1);
  _grnLower = new LED(grnPin2);
  _ylwLower = new LED(ylwPin2);
  _redLower = new LED(redPin2);
}

SIGNAL_6::SIGNAL_6(unsigned grnPin1, unsigned ylwPin1, unsigned redPin1, unsigned grnPin2, unsigned ylwPin2, unsigned redPin2, boolean invert) {
  _grnUpper = new LED(grnPin1, invert);
  _ylwUpper = new LED(ylwPin1, invert);
  _redUpper = new LED(redPin1, invert);
  _grnLower = new LED(grnPin2, invert);
  _ylwLower = new LED(ylwPin2, invert);
  _redLower = new LED(redPin2, invert);
}

void SIGNAL_6::refresh() {
  _grnUpper->refresh();
  _ylwUpper->refresh();
  _redUpper->refresh();
  _grnLower->refresh();
  _ylwLower->refresh();
  _redLower->refresh();
}

void SIGNAL_6::setAspect(unsigned aspect) {
  switch (aspect) {
    case RULE_405:     // Green over Red
      _grnUpper->on();
      _ylwUpper->off();
      _redUpper->off();
      _grnLower->off();
      _ylwLower->off();
      _redLower->on();
      break;
      
    case RULE_406:     // Yellow over Flashing Green
      _grnUpper->off();
      _ylwUpper->on();
      _redUpper->off();
      _grnLower->blink(500,500);
      _ylwLower->off();
      _redLower->off();
      break;
      
    case RULE_407:     // Yellow over Green
      _grnUpper->off();
      _ylwUpper->on();
      _redUpper->off();
      _grnLower->on();
      _ylwLower->off();
      _redLower->off();
      break;
      
    case RULE_408:     // Yellow over Yellow
      _grnUpper->off();
      _ylwUpper->on();
      _redUpper->off();
      _grnLower->off();
      _ylwLower->on();
      _redLower->off();
      break;
      
    case RULE_408A:    // Yellow over Flashing Yellow
      _grnUpper->off();
      _ylwUpper->on();
      _redUpper->off();
      _grnLower->off();
      _ylwLower->blink(500,500);
      _redLower->off();
      break;
      
    case RULE_409:     // Flashing Yellow over Red
      _grnUpper->off();
      _ylwUpper->blink(500,500);
      _redUpper->off();
      _grnLower->off();
      _ylwLower->off();
      _redLower->on();
      break;
      
    case RULE_410:     // Yellow over Red
      _grnUpper->off();
      _ylwUpper->on();
      _redUpper->off();
      _grnLower->on();
      _ylwLower->off();
      _redLower->off();
      break;
      
    case RULE_421:     // Red over Green
      _grnUpper->off();
      _ylwUpper->off();
      _redUpper->on();
      _grnLower->on();
      _ylwLower->off();
      _redLower->off();
      break;
      
    case RULE_425:     // Red over Flashing Yellow
      _grnUpper->off();
      _ylwUpper->off();
      _redUpper->on();
      _grnLower->off();
      _ylwLower->blink(500,500);
      _redLower->off();
      break;
      
    case RULE_426:     // Red over Yellow 
      _grnUpper->off();
      _ylwUpper->off();
      _redUpper->on();
      _grnLower->off();
      _ylwLower->on();
      _redLower->off();
      break;
      
    case RULE_429:     // Red over Red
      _grnUpper->off();
      _ylwUpper->off();
      _redUpper->on();
      _grnLower->off();
      _ylwLower->off();
      _redLower->on();
      break;
              
  }
}
