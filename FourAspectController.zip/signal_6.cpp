#include "Arduino.h"
#include "signal_6.h"

/*
 *  This class controls a six-light signal with six distinct LEDs
 *  Note the LEDs might be two true tricolor LEDs
 */

SIGNAL_6::SIGNAL_6(unsigned grnPin1, unsigned ylwPin1, unsigned redPin1, unsigned grnPin2, unsigned ylwPin2, unsigned redPin2) {
  _grnUpper = new LED(grnPin1);
  _ylwUpper = new LED(ylwPin1);
  _redUpper = new LED(redPin1);
  _grnLower = new LED(grnPin2);
  _ylwLower = new LED(ylwPin2);
  _redLower = new LED(redPin2);
}

SIGNAL_6::SIGNAL_6(unsigned grnPin1, unsigned ylwPin1, unsigned redPin1, unsigned grnPin2, unsigned ylwPin2, unsigned redPin2, boolean invert) {
  _grnUpper = new LED(grnPin1, invert);
  _ylwUpper = new LED(ylwPin1, invert);
  _redUpper = new LED(redPin1, invert);
  _grnLower = new LED(grnPin2, invert);
  _ylwLower = new LED(ylwPin2, invert);
  _redLower = new LED(redPin2, invert);
}

void SIGNAL_6::refresh() {
  _grnUpper->refresh();
  _ylwUpper->refresh();
  _redUpper->refresh();
  _grnLower->refresh();
  _ylwLower->refresh();
  _redLower->refresh();
}

void SIGNAL_6::setAspect(unsigned aspect) {
  switch (aspect) {
    case SIG_CLR:
    // Clear: Implement as steady green
      _grnUpper->on();
      _ylwUpper->off();
      _redUpper->off();
      _grnLower->off();
      _ylwLower->off();
      _redLower->on();
      break;
    
    case SIG_DIV_APP_MED:
    // Diverging Approach Medium: NOT IMPLEMENTED    
      break;
    
    case SIG_APP_MED:
    // Approach Medium: Implement as blinking yellow
      _grnUpper->off();
      _ylwUpper->blink(500,500);
      _redUpper->off();
      _grnLower->off();
      _ylwLower->off();
      _redLower->on();
      break;
    
    case SIG_DIV_CLR:
    // Diverging Clear: NOT IMPLEMENTED
      break;
    
    case SIG_APP:
    // Approach: Implement as steady yellow
      _grnUpper->off();
      _ylwUpper->on();
      _redUpper->off();
      _grnLower->off();
      _ylwLower->off();
      _redLower->on();
      break;
      
    case SIG_DIV_APP:
    // Diverging Approach: NOT IMPLEMENTED
      break;
      
    case SIG_RESTR:
    // Restricting: NOT IMPLEMENTED
      break;
      
    case SIG_STOP_PROC:
    // Stop and Proceed: NOT IMPLEMENTED
      break;
      
    case SIG_STOP:
    // Stop: Implemented as steady red
      _grnUpper->off();
      _ylwUpper->off();
      _redUpper->on();
      _grnLower->off();
      _ylwLower->off();
      _redLower->on();
      break;
    
  }
}
