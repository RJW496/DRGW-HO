#if !defined __SIGNAL__
#define __SIGNAL__

#include "bicolor.h"

//  Code for a 2 head signal with bicolor LEDs for lights
//
//  Supports the following aspects:
//      Aspect                Display                   
//      -----------------     -------------------------
#define RULE_405        1     // Green over Red
#define RULE_406        2     // Yellow over Flashing Green
#define RULE_407        3     // Yellow over Green
#define RULE_408        4     // Yellow over Yellow
#define RULE_408A       5     // Yellow over Flashing Yellow
#define RULE_409        6     // Flashing Yellow over Red
#define RULE_410        7     // Yellow over Red
#define RULE_421        8     // Red over Green
#define RULE_425        9     // Red over Flashing Yellow
#define RULE_426       10     // Red over Yellow 
#define RULE_429       11     // Red over Red
#define SIG_CLR         1     // Green over Red           
#define SIG_DIV_APP_MED 2 
#define SIG_APP_MED     3     // Flashing Yellow over Red 
#define SIG_DIV_CLR     4
#define SIG_APP         5     // Steady Yellow over Red   
#define SIG_DIV_APP     6
#define SIG_RESTR       7
#define SIG_STOP_PROC   8
#define SIG_STOP        9     // Red over Red             


class BC_SIGNAL {
  public:
    BC_SIGNAL(unsigned pin1, unsigned pin2, unsigned pin3, unsigned pin4);
    BC_SIGNAL(unsigned pin1, unsigned pin2, unsigned grnDelay1, unsigned redDelay1, 
              unsigned pin3, unsigned pin4, unsigned grnDelay2, unsigned redDelay2);
    void setAspect(unsigned aspect);
    void refresh();
  private:
    BICOLOR* upper;
    BICOLOR* lower;
};

#endif
