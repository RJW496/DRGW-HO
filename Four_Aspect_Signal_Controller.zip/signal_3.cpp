#include "Arduino.h"
#include "signal_3.h"

/*
 *  This class controls a three-light signal with three distinct LEDs
 *  Note the LEDs might be a single true tricolor LED
 */

SIGNAL_3::SIGNAL_3(unsigned grnPin, unsigned ylwPin, unsigned redPin) {
  _grn = new LED(grnPin);
  _ylw = new LED(ylwPin);
  _red = new LED(redPin);
}

SIGNAL_3::SIGNAL_3(unsigned grnPin, unsigned ylwPin, unsigned redPin, boolean invert) {
  _grn = new LED(grnPin, invert);
  _ylw = new LED(ylwPin, invert);
  _red = new LED(redPin, invert);
}

void SIGNAL_3::refresh() {
  _grn->refresh();
  _ylw->refresh();
  _red->refresh();
}

void SIGNAL_3::setAspect(unsigned aspect) {
  switch (aspect) {
    case SIG_CLR:
    // Clear: Implement as steady green
      _grn->on();
      _ylw->off();
      _red->off();
      break;
    
    case SIG_DIV_APP_MED:
    // Diverging Approach Medium: NOT IMPLEMENTED    
      break;
    
    case SIG_APP_MED:
    // Approach Medium: Implement as blinking yellow
      _grn->off();
      _ylw->blink(500,500);
      _red->off();
      break;
    
    case SIG_DIV_CLR:
    // Diverging Clear: NOT IMPLEMENTED
      break;
    
    case SIG_APP:
    // Approach: Implement as steady yellow
      _grn->off();
      _ylw->on();
      _red->off();
      break;
      
    case SIG_DIV_APP:
    // Diverging Approach: NOT IMPLEMENTED
      break;
      
    case SIG_RESTR:
    // Restricting: NOT IMPLEMENTED
      break;
      
    case SIG_STOP_PROC:
    // Stop and Proceed: NOT IMPLEMENTED
      break;
      
    case SIG_STOP:
    // Stop: Implemented as steady red
      _grn->off();
      _ylw->off();
      _red->on();
      break;
    
  }
}
