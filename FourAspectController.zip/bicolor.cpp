#include "Arduino.h"
#include "bicolor.h"

/*
 *  This class controls a two-color LED with two leads
 */

BICOLOR::BICOLOR(unsigned pin1, unsigned pin2) {
  _pin1 = pin1;
  _pin2 = pin2;
  _grnDelay = 10;           // default values
  _redDelay = 3;            //
  pinMode(_pin1,OUTPUT);
  pinMode(_pin2,OUTPUT);
  digitalWrite(_pin1,LOW);
  digitalWrite(_pin2,LOW);
  _color = OFF;
  _state = OFF;
  _blink = false;
}

// For a greener yellow, increase grnDelay
// For a redder yellow, increase redDelay
BICOLOR::BICOLOR(unsigned pin1, unsigned pin2, unsigned grnDelay, unsigned redDelay) {
  _pin1 = pin1;
  _pin2 = pin2;
  _grnDelay = grnDelay;
  _redDelay = redDelay;
  pinMode(_pin1,OUTPUT);
  pinMode(_pin2,OUTPUT);
  digitalWrite(_pin1,LOW);
  digitalWrite(_pin2,LOW);
  _color = OFF;
  _state = OFF;
  _blink = false;
}

void BICOLOR::on(int color) {
  switch (color) {
    case GRN:
      _color = color;
      _blink = false;
      _grn();
      break;
    case RED:
      _color = color;
      _blink = false;
      _red();
      break;
    case YLW:
      _color = color;
      _blink = false;
      _timex = millis();
      _grn();
      break;
  }
}

void BICOLOR::off() {
  _color = OFF;
  _state = OFF;
  _blink = false;
  digitalWrite(_pin1,LOW);
  digitalWrite(_pin2,LOW);
}

void BICOLOR::setGrnDelay(unsigned delay) {
  if (delay != 0) _grnDelay = delay;        // insure _grnDelay is never zero
}

void BICOLOR::setRedDelay(unsigned delay) {
  if (delay != 0) _redDelay = delay;         // insure _redDelay is never zero
}

void BICOLOR::blink(unsigned color, unsigned onTime, unsigned offTime) {
  _color = color;
  _onTime = onTime;
  _offTime = offTime;
  _blink = true;
  _cycleStart = millis();
}

void BICOLOR::refresh() {
  unsigned long currTime;
  
  // First, handle yellow color transitions
  if (_color==YLW && _state!=OFF) {
    currTime = millis() - _timex;
    if (_state==GRN) {
      if (currTime > _grnDelay) {
        _red();
        _timex = millis();
      }
    }
    else {
      if (currTime > _redDelay) {
        _grn();
        _timex = millis();
      }
    }
  }
  
  // Next, handle blinking color
  if (_blink) {
    currTime = millis() - _cycleStart;
    if ((_state!=OFF) && (currTime>_onTime)) {
      _cycleStart = millis();
      _off();
    }
    else if ((_state==OFF) && (currTime>_offTime)) {    
      _cycleStart = millis();
      switch(_color) {
        case RED:
          _red();
          break;
        case GRN:
          _grn();
          break;
        case YLW:
          _timex = _cycleStart;
          _grn();
          break;
      }
    }
  }
}

//  The following primatives set the LED state to GRN, YLW, or OFF
//  without altering any of the other variables that control LED
//  color or lighting

void BICOLOR::_grn() {
  _state = GRN;
  digitalWrite(_pin1,HIGH);
  digitalWrite(_pin2,LOW);
}

void BICOLOR::_red() {
  _state = RED;
  digitalWrite(_pin1,LOW);
  digitalWrite(_pin2,HIGH);
}

void BICOLOR::_off() {
  _state = OFF;
  digitalWrite(_pin1,LOW);
  digitalWrite(_pin2,LOW);
}
