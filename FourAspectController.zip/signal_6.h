#if !defined __SIGNAL_6__
#define __SIGNAL_6__

#include <LED.h>

//  Code for a 2 head signal, each head displaying green, yellow, or red
//
//  Supports the following aspects:
//      Aspect                Display                   
//      -----------------     -------------------------
#define SIG_CLR         1  // Green over Red  
#define SIG_DIV_APP_MED 2
#define SIG_APP_MED     3  // Flashing Yellow over Red
#define SIG_DIV_CLR     4
#define SIG_APP         5  // Steady Yellow over Red  
#define SIG_DIV_APP     6
#define SIG_RESTR       7
#define SIG_STOP_PROC   8
#define SIG_STOP        9  // Red over Red   

class SIGNAL_6 {
  public:
    SIGNAL_6(unsigned grnPin1, unsigned ylwPin1, unsigned redPin1, unsigned grnPin2, unsigned ylwPin2, unsigned redPin2);
    SIGNAL_6(unsigned grnPin1, unsigned ylwPin1, unsigned redPin1, unsigned grnPin2, unsigned ylwPin2, unsigned redPin2, boolean invert);
    void setAspect (unsigned aspect);
    void refresh();
  private:
    LED* _grnUpper;
    LED* _ylwUpper;
    LED* _redUpper;
    LED* _grnLower;
    LED* _ylwLower;
    LED* _redLower;
};


#endif
