#include "Arduino.h"
#include "bc_signal.h"

/*
 *  This class controls a two-LED signal using bicolor red/green LEDs
 *  Forward power lights the green LED; reverse power lights the red LED
 *  Yellow is achieved by alternating rapidly between red and green
 */

BC_SIGNAL::BC_SIGNAL(unsigned pin1, unsigned pin2, unsigned pin3, unsigned pin4) {
  upper = new BICOLOR(pin1, pin2);
  lower = new BICOLOR(pin3, pin4);
}

BC_SIGNAL::BC_SIGNAL(unsigned pin1, unsigned pin2, 
                     unsigned grnDelay1, unsigned redDelay1,
                     unsigned pin3, unsigned pin4, 
                     unsigned grnDelay2, unsigned redDelay2) {
  upper = new BICOLOR(pin1, pin2, grnDelay1, redDelay1);
  lower = new BICOLOR(pin3, pin4, grnDelay2, redDelay2);
}

void BC_SIGNAL::setAspect(unsigned aspect) {
  switch(aspect){
    case SIG_CLR:
      upper->on(GRN);
      lower->on(RED);
      break;
      
    case SIG_APP_MED:
      upper->blink(YLW,750,750);
      lower->on(RED);
      break;
      
    case SIG_APP:
      upper->on(YLW);
      lower->on(RED);
      break;
      
    case SIG_STOP:
      upper->on(RED);
      lower->on(RED);
      break;
  }
}

void BC_SIGNAL::refresh() {
  upper->refresh();
  lower->refresh();
}
