#if !defined __SIGNAL_3__
#define __SIGNAL_3__

#include "LED.h"

//  Code for a 1 head signal displaying green, yellow, or red
//
//  Supports the following aspects:
//      Aspect                Display                   
//      -----------------     -------------------------
#define SIG_CLR         1  // Green  
#define SIG_DIV_APP_MED 2
#define SIG_APP_MED     3  // Flashing Yellow
#define SIG_DIV_CLR     4
#define SIG_APP         5  // Steady Yellow  
#define SIG_DIV_APP     6
#define SIG_RESTR       7
#define SIG_STOP_PROC   8
#define SIG_STOP        9  // Red  

class SIGNAL_3 {
  public:
    SIGNAL_3(unsigned grnPin, unsigned ylwPin, unsigned redPin);
    SIGNAL_3(unsigned grnPin, unsigned ylwPin, unsigned redPin, boolean invert);
    void setAspect (unsigned aspect);
    void refresh();
  private:
    LED* _grn;
    LED* _ylw;
    LED* _red;
};


#endif
